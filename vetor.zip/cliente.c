#include <stdlib.h> // para funcao exit()
#include <stdio.h>
#include "vetor.h"

int main()
{
  Vetor *V;
  int tam;
  float valor;



  printf("Forneca o tamanho do vetor: ");
  scanf("%d", &tam);

  V = criar(tam);
  if (V == NULL) {
    printf("Erro: nao foi possivel criar o vetor\n");
    exit(1);
  }

  for (int i = 0; i < tamanho(V); i++) {
    printf("Digite o %do. valor: ", i+1);
    scanf("%f", &valor);
    inserir(valor, V, i);
  }
  remover(V, 1);
  valor = acessar(V, 3, &valor);
  printf("acessar eh %f",valor);
  /*for (int i = 0; i < tamanho(V); i++) {
    acessar(V, i, &valor);
    printf("%f ", valor);
  }*/

  printf("%f",V->dados[1]);

  destruir(V);
  return 0;
}
