struct vetor {
  float dados[10];
  int tamanho;
};

typedef struct vetor Vetor;

Vetor *criar(int tam);
void destruir(Vetor *vet);
int inserir(float valor, Vetor *vet, int pos);
int acessar(Vetor *vet, int pos, float *valor);
int tamanho(Vetor *vet);
float soma(Vetor *vet);
float media(Vetor *vet);
float acha_maior(Vetor *vet);
void remover(Vetor *vet, int pos);



