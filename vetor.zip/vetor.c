#include "vetor.h"
#include <stdlib.h>

/*
  Entrada: valor inteiro que representa o tamanho do vetor
  Saida: ponteiro para o vetor, ou NULL caso nao seja possivel cria-lo
  Pre-condicao: o tamanho deve ser menor ou igual ao tamanho maximo do vetor (ou seja, 10)
  Pos-condicao: nao existe
*/
Vetor *criar(int tam)
{
  Vetor *vet;

  vet = malloc(sizeof(Vetor));
  vet->tamanho = tam;

  return vet;
}

/*
  Entrada: ponteiro para um vetor
  Saida: nao existe
  Pre-condicao: nao existe
  Pos-condicao: memoria do vetor eh desalocada
*/
void destruir(Vetor *vet)
{
  if (vet != NULL) free(vet);
}

/*
  Entrada: um valor em ponto flutuante, um ponteiro para vetor e a posicao onde o valor sera inserido
  Saida: 1, se a posicao for valida, 0 caso contrario
  Pre-condicao: o ponteiro tem que ser valido
  Pos-condicao: o valor na posicao eh modificado
*/
int inserir(float valor, Vetor *vet, int pos)
{
  if (pos < 0 || pos >= vet->tamanho)
    return 0;

  vet->dados[pos] = valor;
  return 1;
}

/*
  Entrada: um ponteiro para vetor, uma posicao e um valor em ponto flutuante passado por referencia
  Saida: 1, se a posicao for valida, 0 caso contrario
  Pre-condicao: o ponteiro tem que ser valido
  Pos-condicao: a variavel valor eh modificada
*/
int acessar(Vetor *vet, int pos, float *valor)
{
  if (pos < 0 || pos >= vet->tamanho)
    return 0;

  *valor = vet->dados[pos];
  return 1;
}

/*
  Entrada: um ponteiro para vetor
  Saida: tamanho do vetor
  Pre-condicao: ponteiro tem que ser valido
  Pos-condicao: nao existe
*/
int tamanho(Vetor *vet) {
  return vet->tamanho;
}

/*
  Entrada: um ponteiro para vetor
  Saida: soma do vetor
  Pre-condicao: ponteiro tem que ser valido
  Pos-condicao: nao existe
*/
float soma(Vetor *vet){
    float total = 0;
    float temp;

    for (int i=0; i<tamanho(vet); i++){
        acessar(vet, i, &temp);
        total = total + temp;

    }
    return(total);
}

/*
  Entrada: um ponteiro para vetor
  Saida: media do vetor
  Pre-condicao: ponteiro tem que ser valido
  Pos-condicao: nao existe
*/
float media(Vetor *vet){
    float temp=0;
    temp = soma(vet) / tamanho(vet);
    return (temp);
}

/*
  Entrada: um ponteiro para vetor
  Saida: o maior elemento do vetor
  Pre-condicao: ponteiro tem que ser valido
  Pos-condicao: nao existe
*/
float acha_maior(Vetor *vet){
    float valor=0;
    float maior;
    for(int k=0; k<tamanho(vet);k++){
        acessar(vet, k, &valor);
        if(valor > maior){
            maior = valor;
        }
    }
    return(maior);
}

void remover(Vetor *vet, int pos){
    float valor=0;
    for(int k=pos; k < vet->tamanho-1; k++){
        vet->dados[k] = vet->dados[k+1];
    }
    vet->tamanho = vet->tamanho - 1;
}
